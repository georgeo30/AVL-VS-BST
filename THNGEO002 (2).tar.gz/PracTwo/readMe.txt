readMe

The make file used in this program has 3 methods , make run to compile the java files. Make clear to clear the files and make doc to create java docs for this assignment.

>>  make  
//type make into the command line once  you’re in the  folder PracOne to compile the files

>> make runBST 
//runs and prints the printAlldateTime methods  for PowerBSTApp

>> make runAVL 
// runs and prints the printAlldateTime methods  for PowerAVLApp

>> clean
// removes the .class files created in bin and the java docs created in doc

>> doc


To be able to search for a date/time item. User must redirect themselves to the bin directory and then use the commands 

>> java PowerAVLApp “date/time” 
//This will output the corespoding voltage and power and write the search count to a file 

>> java PowerBSTApp “date/time” 
// this is the same as above but uses the Binary search tree.


*NOTE**  the user has to make use of the csv file  which is stored outside the bin folder when using the java commands. A easy way to do this would be to add the csv file to bin and then use the java commands from there

	when the user is testing the FileWithSearchKeys.txt they must move the FileWithSearchKeys.txt into the bin folder and then use the java 	commands from the terminal in the bin folder.

When executing the make methods, the csv file must be in the directory of the makefile (PracTwo)

