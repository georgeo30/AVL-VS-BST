#!/bin/bash
file="FileWithSearchKeys.txt"

sfile="subsetFile.txt"
nfile="subsetCount.txt"
bfile="bestCountperSubset.txt"
wfile="worstCountperSubset.txt"
afile="averageCountperSubset.txt"
just="g"
touch $sfile
for subset in {1..5}
do	
	head -$subset $file >> $sfile
	while read -r line; do
		name="$line$just"
		java PowerBSTApp "$name" >> $nfile
			best=1000000
			worst=0
			total=0
			c=0
			while read -r counts; do
				let "total += counts"
				let "c += 1"
				if [ $counts -gt $worst ]
				then
					let "worst = counts"
				fi
				if [ $counts -lt $best ]
				then
					let "best = counts"
				fi
			done < "$nfile"
		
	done < "$sfile"
		let "average = total/c"
		echo "$best" >> "$bfile"
		echo "$worst" >> "$wfile"
		echo "$average" >> "$afile"
	rm $sfile
	rm $nfile 
	  
done
