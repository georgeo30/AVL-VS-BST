/**
 *
 * @author Georgeo
 */

//importing files
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

public class PowerBSTApp
{   
	
    public static String toFile=new String();
    public static BinarySearchTree x=new BinarySearchTree();
    public static String[] list =new String[500];
    public static int listC=0;
    /**
    *Main Method
    * reading in csv file and performing actions depending on user input
    * commented out code it to read in insertions
    * can run subset testing method if needed
    */
    public static void main(String[] args)
    {try                                                                 
        {                               
            Scanner csvFile =new Scanner(new File("cleaned_data.csv"));     
            csvFile.nextLine();                                             
            csvFile.useDelimiter("\n");                                     
            while(csvFile.hasNext())                                        
            {   
		        
                String[] temp=csvFile.nextLine().split(",");
                list[listC]=temp[0];
                listC++;                                                    
                x.insert(temp[0]+","+temp[1]+","+temp[3]);
                //String in=x.insertCount()+"";
                //writeToFile(in);
                //x.setICToZero();                                          
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());                             
        }
        if (args.length <1)
        {
            x.inOrder(x.root);                                              
        }
        else if(args[0].equals("FileWithSearchKeys.txt")){
                searchingFile();
            }
        else if(args[0].length()==20){
            String sub = args[0].substring(0, args[0].length() - 1);
            BinarySearchTree.Node k =x.search(x.root,sub);
            if (k==null){
                System.out.println("Date/time not found");
            }
            else{
                System.out.println(x.counter());
            }
        }
        else
        {
            
            BinarySearchTree.Node k =x.search(x.root,args[0]);              
            if (k==null)                                                    
            {
                int nf=x.counter();
                x.setICToZero();
                System.out.println("Date/time not found");
                writeToFile("Date/time not found. Searches:"+nf);
                
            }
            
            else
            {
                toFile="Date/time: "+args[0]+" count: "+x.counter();             
                System.out.println(k.key);                            
                writeToFile(toFile);                                        
            }
            
        }
	
    }
    /**
     * writeToFile method 
     * takes in a param and writes that string to a file
     * used in testing cases through out the experiment
     * @param toFile 
     */
    public static void writeToFile(String toFile)
    {
        try
        {
            FileWriter fileWriter = new FileWriter("Part4test",true);        
            fileWriter.write( toFile +"\n");
            fileWriter.close();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    /**
     * This writeTooFile method is used when writing the best average and worst cases to a file when doing 500 subset testing
     * consists of standard try catch block
     * @param fName
     * @param value 
     */
    public static void writeTooFile(String fName,float value){
        try{
            FileWriter file =new FileWriter(fName,true);
            file.write(value+"\n");
            file.close();
            
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    /**
     * searchingFile method 
     * used to trace through a user input textfile name and return the corresponding counts for each date/time in the file
     */
    public static void searchingFile(){
        try{
            Scanner searchFile=new Scanner(new File("FileWithSearchKeys.txt"));
           
            searchFile.nextLine();
            searchFile.useDelimiter("\n");
            while (searchFile.hasNextLine()){
                BinarySearchTree.Node k =x.search(x.root,searchFile.nextLine());
                System.out.println(k.key+" took "+x.counter()+"counts insert:"+x.insertCount());
                
                
                x.setSCToZero();
                
            }
            
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            }
    }
    /**
     * Subset testing for all N of the date/item 
     * quick execution compared to my bash script
     */
    public static void subsetTestingBST(){
        for (int subset=0;subset<501;subset++){
            
            int min = 10000;
            float total = 0;
            int max= 0;
            for (int i=0;i<subset;i++){
                BinarySearchTree.search(BinarySearchTree.root,list[i]);
		total += BinarySearchTree.counter();
		if (BinarySearchTree.counter() < min){
                    min = BinarySearchTree.counter();
                }
		if (BinarySearchTree.counter() > max){
                    max = BinarySearchTree.counter();
                }
		if (i==(subset-1)){
                    writeTooFile("BST_Average.csv",(total/subset));
                    writeTooFile("BST_Best.csv",min);
                    writeTooFile("BST_Worst.csv",max);
                }
                BinarySearchTree.setSCToZero();
        }}
    }
    
    
    
}
