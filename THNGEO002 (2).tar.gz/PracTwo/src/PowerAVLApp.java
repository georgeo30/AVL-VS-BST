/**
 *
 * @author Georgeo
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.*;
public class PowerAVLApp {
    /**creating an object x of AVLTree**/
    public static AVLTree x= new AVLTree();
    public static String[] list =new String[500];
    public static int listC=0;
    /**
    *Main Method
    * reading in csv file and performing actions depending on user input
    * commented out code it to read in insertions
    * can run subset testing method if needed
    */
    public static void main(String[] args) {
        try{
            Scanner csvFile=new Scanner(new File("cleaned_data.csv"));
            
            csvFile.nextLine();
            csvFile.useDelimiter("\n");
            while (csvFile.hasNextLine()){
                
                String[] temp=csvFile.nextLine().split(",");
                list[listC]=temp[0];
                listC++;
                x.insert(temp[0]+","+temp[1]+","+temp[3]);
                //String in=x.insertCount()+"";
                //writeToFile(in);
                //x.setICToZero(); 
                
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        if (args.length<1){
            
            x.preOrder(x.node);
        }
        else if(args[0].equals("FileWithSearchKeys.txt")){
            searchingFile();
        }
        else if(args[0].length()==20){
            String sub = args[0].substring(0, args[0].length() - 1);
            AVLTree.Node k =x.search(x.node,sub);
            if (k==null){
                System.out.println("Date/time not found");
            }
            else{
                System.out.println(x.searchCount());
            }
        }
        else{
            AVLTree.Node k =x.search(x.node,args[0]);
            if (k==null){
                int nf=x.searchCount();
                x.setICToZero();
                System.out.println("Date/time not found");
                writeToFile("Date/time not found. Searches:"+nf);
            }
            else{
                System.out.println(k.key);
                String part2="Date/time: "+args[0]+" count: "+x.searchCount();
                writeToFile(part2);
            }
        }
        
    }
    /**
     * searchingFile method 
     * used to trace through a user input textfile name and return the corresponding counts for each date/time in the file
     */
    public static void searchingFile(){
        try{
            Scanner searchFile=new Scanner(new File("FileWithSearchKeys.txt"));
           
            //searchFile.nextLine();
            searchFile.useDelimiter("\n");
            while (searchFile.hasNextLine()){
                AVLTree.Node k =x.search(x.node,searchFile.nextLine());
                System.out.println(k.key+" took "+x.searchCount()+"counts insert:"+x.insertCount());
                writeToFile(x.searchCount()+"");
                x.setSCToZero();
            }
            
        }
            catch(Exception e){
            System.out.println(e.getMessage());
            }
    }
    /**
     * writeToFile method 
     * takes in a param and writes that string to a file
     * used in testing cases through out the experiment
     * @param toFile 
     */
    public static void writeToFile(String toFile){
        try{
            FileWriter file =new FileWriter("Part2test",true);
            file.write(toFile+"\n");
            file.close();
            
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    /**
     * This writeTooFile method is used when writing the best average and worst cases to a file when doing 500 subset testing
     * consists of standard try catch block
     * @param fName
     * @param value 
     */
    public static void writeTooFile(String fName,float value){
        try{
            FileWriter file =new FileWriter(fName,true);
            file.write(value+"\n");
            file.close();
            
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    /**
     * Subset testing for all N of the date/item 
     * quick execution compared to my bash script
     */
    public static void subsetTestingAVL(){
        for (int subset=0;subset<501;subset++){
            
            int min = 10000;
            float total = 0;
            int max= 0;
            for (int i=0;i<subset;i++){
                AVLTree.search(AVLTree.node,list[i]);
		total += AVLTree.searchCount();
		if (AVLTree.searchCount() < min){
                    min = AVLTree.searchCount();
                }
		if (AVLTree.searchCount() > max){
                    max = AVLTree.searchCount();
                }
		if (i==(subset-1)){
                    writeTooFile("AVL_Average.csv",(total/subset));
                    writeTooFile("AVL_Best.csv",min);
                    writeTooFile("AVL_Worst.csv",max);
                }
                AVLTree.setSCToZero();
        }}
    }
}
