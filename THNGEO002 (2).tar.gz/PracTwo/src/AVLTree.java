/**
 * the AVLTree was originally got from geeksforgeeks website. but was then later modified by adding methods and editing existing methods to work in respect to this assignment and my code
 * please read the report to get the full accessible link to the original source code
 * @author Georgeo
 */
public class AVLTree {
   public class Node{
       public String key;
       public int height;
       public Node left, right;
       /**
        * Inner class Node of AVLTree
        * @param item 
        */
       public Node(String item){
           key=item;
           height =1;
       }
   }
 public static Node node;
 public static int searchC;
 public static int insertC;
 /**
  * constructor for AVLTree
  */
 public AVLTree(){
     node=null;
 }
 /**
  * method to return the height when given the Node
  * @param N
  * @return 
  */
 public int height (Node N){
    if (N==null){
        return 0;
    }
    return N.height;
 }
 
/**
 * checking max between to values 
 * need when doing the rotations
 * @param a
 * @param b
 * @return 
 */
 public int max(int a, int b){
     return (a>b) ? a : b;
 }
 
 /**
  * right rotate subtree rooted with y
  * @param y
  * @return
  */
 Node rightRotate(Node y){
     Node x = y.left;
     Node T2 =x.right;
     
     //perform rotation
     x.right=y;
     y.left =T2;
     
     //update height s
     y.height=max(height(y.left),height(y.right))+1;
     x.height=max(height(x.left),height(x.right))+1;
     
     //return new root
     return x;
 }
 
 /**
  * left rotate subtree rooted with x
  * @param x
  * @return
  */
 public Node leftRotate(Node x){
     Node y=x.right;
     Node T2=y.left;
     
     //perform rotation
     y.left =x;
     x.right=T2;
     
     //update height
     x.height=max(height(x.left),height(x.right))+1;
     y.height=max(height(y.left),height(y.right))+1;
     
     //return height
     return y;
 }
 
 /**
  * get balance factor of node N
  * @param N
  * @return
  */
public int getBalance(Node N){
    if (N==null){
        return 0;
    }
    return height(N.left)-height(N.right);
}
/**
 * search method for AVL Tree
 * @param node
 * @param key
 * @return
 */
public static Node search(Node node,String key){
    if (node==null){
        return null;
    }
    searchC++;
    int x=key.compareTo(node.key.split(",")[0]);
    if (node==null || x==0){
        return node;
    }
    if (x<0){
        return search(node.left,key);
    }
    return search(node.right,key);
    
}
/**
 * calls insertRec
 * @param key 
 */
public void insert(String key){
    node=insertRec(node,key);
}
/**
 * insert method for AVL tree
 * @param node
 * @param key
 * @return
 */
public Node insertRec(Node node, String key){
    /*normal AVL insert*/
    //System.out.println(key);
    if (node ==null){
        return(new Node(key));
    }
    insertC++;
    int x=key.compareTo(node.key);
    if (x<0){
        node.left=insertRec(node.left,key);
    }
    else if (x>0){
        node.right=insertRec(node.right,key);
    }
    else
        return node;
    
    /*update height of ancestor node*/
    node.height=1+max(height(node.left),height(node.right));
    
    /*get balance factor from ancestor node to test if this is uunbalanced*/
    int balance =getBalance(node);
    /*left-left case*/
    
    if(balance >1){
        insertC++;
        if (key.compareTo(node.left.key)<0){
            return rightRotate(node);
        }
    }
    /*right-right case*/
    
    if (balance <-1){
        insertC++;
        if (key.compareTo(node.right.key)>0){
        return leftRotate(node);
        }    
    }
    /*left right case*/
    if (balance>1){
        insertC++;
        if(key.compareTo(node.left.key)>0){
        node.left=leftRotate(node.left);
        return rightRotate(node);
        }
    }
    /*right left case*/
    
    if (balance <-1){
        insertC++;
        if (key.compareTo(node.right.key)<0){
             node.right=rightRotate(node.right);
            return leftRotate(node);
        }
    }
    return node;
}
/**
 * preOrder Traversal print
 * @param node
 */
public void preOrder(Node node){
    if (node!=null){
        System.out.println(node.key+"");
        preOrder(node.left);
        preOrder(node.right);
    }
}
/**
 * inOrder Traversal print
 * @param node
 */
public void inOrder(Node node){
    if (node==null){}
    else{
        inOrder(node.left);
        System.out.println(node.key);
        
        inOrder(node.right);
    }
}
/**
     * returns searchCount
     * @return 
     */
public static int searchCount(){
    return searchC;
}
/**
* sets opCount to zero
* @return
*/
public int insertCount(){
    return insertC;
}
/**
 * sets searchCount to 0
 */
public static void setSCToZero(){
    searchC=0;
}
/**
 * sets insert Count to zero
 */
public void setICToZero(){
    insertC=0;
}


}
