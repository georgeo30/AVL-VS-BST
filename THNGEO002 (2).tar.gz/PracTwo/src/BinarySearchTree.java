/**
 * the BInarySearchTree was originally got from geeksforgeeks website. but was then later modified by adding methods and editing existing methods to work in respect to this assignment and my code
 * please read the report to get the full accessible link to the original source code
 * @author Georgeo
 */
public class BinarySearchTree
{
    /*class that contains left and right child*/
    public class Node
    {
        public String key;
        public Node left, right;
        /**
         * constructor for inner class Node of BinarySearchTree
         * initializes
         * @param item 
         */
        public Node(String item)
        {
            key=item;
            left=right=null;
        }
    }
    
    //root of bst
    public static Node root;
    public static int opCount=0;
    public static int insertC;
    /**
     * constructor of the BinarySearchTree
     * sets root to null
     */
    public BinarySearchTree()
    {
        root=null;
    }
    /**
     * insert takes in a key to be inserted
     * calls insertRec ssending two params
     * @param key 
     */
    public void insert(String key)
    {
        root=insertRec(root,key);
    }
    /**
     * inserts the date/time in sorect place
     * @param root
     * @param key
     * @return 
     */
    public Node insertRec(Node root,String key)
    {
        //checks if tree is empty and if so then returns a new node
        if (root==null)
        {
            root =new Node(key);
            return root;
        }
        insertC++;
        // recurse down the treeotherwise
        int x=key.compareTo(root.key);
        if (x<0)
        {
            root.left=insertRec(root.left,key);
            
        }
        
        else if(x>0)
        {
            root.right=insertRec(root.right,key);
        }
        
            
        return root;
        
    }
    
    /**
     * used to search for a data item in the BinarySearchTree
     * @param root
     * @param key
     * @return 
     */
    public static Node search(Node root, String key)
    {   
        //recursive
        //base case
        
        if (root==null)
        {return null;}
        int x =key.compareTo(root.key.split(",")[0]);
        
        opCount++;
        if (root==null || x==0)
        {
            
            return root;
        }
        
        //if the value is gretaer than the root key
        if (x<0)
        {
            
            return search(root.left,key);
        }
        //if left side is bigger
     
            
            return search(root.right,key);
            
        
        
        
        
    }
    /**
     * inOrder traversal and output of the BinarySearchTree
     * @param root 
     */
    public void inOrder(Node root)
    {
        if (root==null)
        {     }
        else
        {   
            inOrder(root.left);
            System.out.println(root.key);
            inOrder(root.right);
            
        }
        
    }
    /**
     * returns opCount
     * @return 
     */
    public static int counter()
    {
        return opCount;
        
    }
    /**
     * sets opCount to zero
     */
    public static void setSCToZero()
    
    {
        opCount=0;
    }
    /**
     * returns the insert count
     * @return 
     */
    public int insertCount(){
        return insertC;
    }
    /**
     * sets insert count to zero
     */
    public static void setICToZero()
    
    {
        insertC=0;
    }
    
}
